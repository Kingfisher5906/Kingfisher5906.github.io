import React from "react";
import "./style.css";

export const Frame = () => {
  return (
    <div className="frame">
      <div className="div">
        <img className="column-chart-bar" alt="Column chart bar" src="/img/column-chart-bar-chart.png" />
        <div className="overlap-group">
          <div className="rectangle" />
          <div className="text-wrapper">SJP S SchedGen Dashboard</div>
        </div>
      </div>
    </div>
  );
};
